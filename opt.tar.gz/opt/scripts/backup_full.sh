#!/bin/bash

# backup_full.sh - Copia de seguridad de directorios pasados como argumentos.
# Uso: backup_full.sh -h | backup_full.sh -s <origen> -d <destino>
# Opciones:
#   -h         Muestra esta ayuda.
#   -s <ruta>  Origen a respaldar.
#   -d <ruta>  Destino donde guardar el backup.

# Función de ayuda
show_help(){
  echo "Uso: $0 -s <origen> -d <destino>"
  echo "   -h         Mostrar ayuda."
  echo "   -s <ruta>  Directorio o archivo origen."
  echo "   -d <ruta>  Directorio destino (debe estar montado)."
}

# Validar entrada
while getopts "hs:d:" opt; do
  case $opt in
    h) show_help; exit 0 ;;
    s) SRC="$OPTARG" ;;
    d) DST="$OPTARG" ;;
    *) show_help; exit 1 ;;
  esac
done

# Comprobar que origen y destino estén definidos
if [[ -z "$SRC" || -z "$DST" ]]; then
  echo "ERROR: falta orgien o destino."
  show_help
  exit 1
fi

# Verificar que estén montados
if ! mountpoint -q "$SRC"; then
  echo "ERROR: Origen no montado: $SRC"
  exit 1
fi
if ! mountpoint -q "$DST"; then
  echo "ERROR: Destino no montado: $DST"
  exit 1
fi

# Generar nombre con fecha ANSI
FECHA=$(date +%Y%m%d)
NOMBRE="$(basename "$SRC")_bkp_${FECHA}.tar.gz"

# Crear el backup
tar -czf "${DST}/${NOMBRE}" -C "$(dirname "$SRC")" "$(basename "$SRC")" \
  && echo "Backup creado: ${DST}/${NOMBRE}" \
  || { echo "ERROR: Falló tar"; exit 1; }
